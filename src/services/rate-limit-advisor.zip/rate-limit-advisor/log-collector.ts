import { apiClient } from '../api';
import type {
  AccessLogEntry,
  AccessLogResponse,
  SecurityEventEntry,
  SecurityEventResponse,
  CollectionProgress,
} from './types';

// ═══════════════════════════════════════════════════════════════════
// CONFIGURATION
// ═══════════════════════════════════════════════════════════════════

/** Hours per chunk — smaller = more parallel streams = faster */
const CHUNK_HOURS = 4;
/** Max concurrent API scroll streams — keep under API rate limit */
const MAX_CONCURRENCY = 5;
/** Records per scroll page — API max is 500 */
const PAGE_SIZE = 500;
/** Max retries on 429 / transient errors */
const MAX_RETRIES = 3;
/** Base delay for exponential backoff (ms) */
const RETRY_BASE_MS = 2000;

// ═══════════════════════════════════════════════════════════════════
// HELPERS
// ═══════════════════════════════════════════════════════════════════

interface TimeChunk {
  start: string;
  end: string;
  label: string;
}

/** Retry wrapper — backs off on 429 and transient errors */
async function withRetry<T>(fn: () => Promise<T>, label: string): Promise<T> {
  for (let attempt = 0; attempt <= MAX_RETRIES; attempt++) {
    try {
      return await fn();
    } catch (err) {
      const msg = err instanceof Error ? err.message : String(err);
      const is429 = msg.includes('429') || msg.toLowerCase().includes('too many');
      const isTransient = is429 || msg.includes('502') || msg.includes('503') || msg.includes('504');

      if (!isTransient || attempt === MAX_RETRIES) throw err;

      const delay = RETRY_BASE_MS * Math.pow(2, attempt) + Math.random() * 1000;
      console.log(`[LogCollector] ${label}: ${msg} — retry ${attempt + 1}/${MAX_RETRIES} in ${Math.round(delay)}ms`);
      await new Promise(r => setTimeout(r, delay));
    }
  }
  throw new Error('Unreachable');
}

/** Split a time range into N-hour chunks */
function splitIntoChunks(startTime: string, endTime: string, chunkHours: number): TimeChunk[] {
  const chunks: TimeChunk[] = [];
  const start = new Date(startTime).getTime();
  const end = new Date(endTime).getTime();
  const chunkMs = chunkHours * 60 * 60 * 1000;

  let cursor = start;
  while (cursor < end) {
    const chunkEnd = Math.min(cursor + chunkMs, end);
    const d = new Date(cursor);
    const label = `${(d.getUTCMonth() + 1).toString().padStart(2, '0')}/${d.getUTCDate().toString().padStart(2, '0')} ${d.getUTCHours().toString().padStart(2, '0')}:00`;
    chunks.push({
      start: new Date(cursor).toISOString(),
      end: new Date(chunkEnd).toISOString(),
      label,
    });
    cursor = chunkEnd;
  }

  return chunks;
}

/**
 * Concurrency-limited Promise.all — runs at most `limit` tasks at a time.
 */
async function parallelLimit<T>(
  tasks: Array<() => Promise<T>>,
  limit: number
): Promise<T[]> {
  const results: T[] = new Array(tasks.length);
  let nextIdx = 0;

  async function worker() {
    while (nextIdx < tasks.length) {
      const idx = nextIdx++;
      results[idx] = await tasks[idx]();
    }
  }

  const workers = Array.from({ length: Math.min(limit, tasks.length) }, () => worker());
  await Promise.all(workers);
  return results;
}

/**
 * Extract the actual timestamp from a log entry.
 * F5 XC may return timestamps in various field names.
 */
function extractTimestamp(entry: Record<string, unknown>): string | undefined {
  // Try standard F5 XC field names
  for (const key of ['@timestamp', 'time', 'timestamp', 'date', 'event_time']) {
    const val = entry[key];
    if (val && typeof val === 'string') return val;
    if (val && typeof val === 'number') return new Date(val).toISOString();
  }
  return undefined;
}

/**
 * Normalize raw API response entries into our AccessLogEntry shape.
 * The F5 XC API may wrap data in _source (Elasticsearch style) or other structures.
 */
function normalizeLogEntries<T>(rawEntries: unknown[], logType: string): T[] {
  if (rawEntries.length === 0) return [];

  const sample = rawEntries[0] as Record<string, unknown>;
  const sampleKeys = Object.keys(sample);

  // Diagnostic logging — always log first entry structure
  console.log(`[LogCollector] ${logType} sample entry keys (${sampleKeys.length}):`, sampleKeys);
  console.log(`[LogCollector] ${logType} sample fields:`, {
    '@timestamp': sample['@timestamp'],
    time: sample['time'],
    timestamp: sample['timestamp'],
    rsp_code: sample['rsp_code'],
    rsp_code_class: sample['rsp_code_class'],
    rsp_code_details: sample['rsp_code_details'],
    src_ip: sample['src_ip'],
    user: sample['user'],
    req_id: sample['req_id'],
    vh_name: sample['vh_name'],
    sample_rate: sample['sample_rate'],
    method: sample['method'],
    req_path: sample['req_path'],
  });
  // Dump raw JSON of first entry for full visibility
  console.log(`[LogCollector] ${logType} FULL first entry JSON:`, JSON.stringify(sample).slice(0, 3000));

  // Check 1: Fields directly on the object (standard F5 XC format)
  if (extractTimestamp(sample) || sample['rsp_code'] || sample['src_ip'] || sample['req_id']) {
    console.log(`[LogCollector] ${logType}: fields at top level`);
    return rawEntries as T[];
  }

  // Check 2: Elasticsearch _source wrapping
  if (sample._source && typeof sample._source === 'object') {
    console.log(`[LogCollector] ${logType}: detected _source wrapping, unwrapping entries`);
    return rawEntries.map(e => (e as Record<string, unknown>)._source as T);
  }

  // Check 3: Other common wrapper patterns
  for (const wrapperKey of ['log', 'data', 'attributes', 'fields', 'record', 'event']) {
    if (sample[wrapperKey] && typeof sample[wrapperKey] === 'object') {
      const inner = sample[wrapperKey] as Record<string, unknown>;
      if (extractTimestamp(inner) || inner['rsp_code'] || inner['src_ip'] || inner['req_id']) {
        console.log(`[LogCollector] ${logType}: detected data nested under '${wrapperKey}', unwrapping`);
        return rawEntries.map(e => (e as Record<string, unknown>)[wrapperKey] as T);
      }
    }
  }

  // Fallback: dump full first entry to help debug
  console.warn(`[LogCollector] ${logType}: UNKNOWN STRUCTURE. Full first entry:`, JSON.stringify(sample).slice(0, 2000));
  return rawEntries as T[];
}

/** Scroll all pages for one access log chunk */
async function fetchChunkAccessLogs(
  namespace: string,
  query: string,
  chunk: TimeChunk,
  onBatch: (batchSize: number) => void,
  onTotalKnown: (totalHits: number) => void
): Promise<AccessLogEntry[]> {
  const logs: AccessLogEntry[] = [];

  const initial = await withRetry(
    () => apiClient.post<AccessLogResponse>(
      `/api/data/namespaces/${namespace}/access_logs`,
      { query, namespace, start_time: chunk.start, end_time: chunk.end, scroll: true, limit: PAGE_SIZE }
    ),
    `access-logs ${chunk.label}`
  );

  // Parse total_hits carefully — API may return string, number, or object
  const rawHits = initial.total_hits;
  let totalHits = 0;
  if (typeof rawHits === 'number' && isFinite(rawHits)) {
    totalHits = Math.floor(rawHits);
  } else if (typeof rawHits === 'string') {
    totalHits = parseInt(rawHits, 10);
    if (!isFinite(totalHits)) totalHits = 0;
  } else if (rawHits && typeof rawHits === 'object' && 'value' in (rawHits as Record<string, unknown>)) {
    totalHits = parseInt(String((rawHits as Record<string, unknown>).value), 10) || 0;
  }
  if (totalHits <= 0) totalHits = initial.logs?.length || 0;

  console.log(`[LogCollector] Chunk ${chunk.label}: total_hits raw=${JSON.stringify(rawHits)}, parsed=${totalHits}`);

  onTotalKnown(totalHits);

  if (initial.logs) {
    logs.push(...initial.logs);
    onBatch(initial.logs.length);
  }

  let scrollId = initial.scroll_id;
  while (scrollId) {
    try {
      const page = await withRetry(
        () => apiClient.post<AccessLogResponse>(
          `/api/data/namespaces/${namespace}/access_logs/scroll`,
          { scroll_id: scrollId!, namespace }
        ),
        `access-scroll ${chunk.label}`
      );
      if (!page.logs || page.logs.length === 0) break;
      logs.push(...page.logs);
      scrollId = page.scroll_id;
      onBatch(page.logs.length);
    } catch {
      break;
    }
  }

  return logs;
}

/** Scroll all pages for one security events chunk */
async function fetchChunkSecurityEvents(
  namespace: string,
  query: string,
  chunk: TimeChunk,
  onBatch: (batchSize: number) => void,
  onTotalKnown: (totalHits: number) => void
): Promise<SecurityEventEntry[]> {
  const events: SecurityEventEntry[] = [];

  const initial = await withRetry(
    () => apiClient.post<SecurityEventResponse>(
      `/api/data/namespaces/${namespace}/app_security/events`,
      { query, namespace, start_time: chunk.start, end_time: chunk.end, scroll: true, limit: PAGE_SIZE }
    ),
    `security ${chunk.label}`
  );

  const rawHits = initial.total_hits;
  let totalHits = 0;
  if (typeof rawHits === 'number' && isFinite(rawHits)) {
    totalHits = Math.floor(rawHits);
  } else if (typeof rawHits === 'string') {
    totalHits = parseInt(rawHits, 10);
    if (!isFinite(totalHits)) totalHits = 0;
  } else if (rawHits && typeof rawHits === 'object' && 'value' in (rawHits as Record<string, unknown>)) {
    totalHits = parseInt(String((rawHits as Record<string, unknown>).value), 10) || 0;
  }
  if (totalHits <= 0) totalHits = initial.events?.length || 0;

  console.log(`[LogCollector] Security chunk ${chunk.label}: total_hits raw=${JSON.stringify(rawHits)}, parsed=${totalHits}`);

  onTotalKnown(totalHits);

  if (initial.events) {
    events.push(...initial.events);
    onBatch(initial.events.length);
  }

  let scrollId = initial.scroll_id;
  while (scrollId) {
    try {
      const page = await withRetry(
        () => apiClient.post<SecurityEventResponse>(
          `/api/data/namespaces/${namespace}/app_security/events/scroll`,
          { scroll_id: scrollId!, namespace }
        ),
        `security-scroll ${chunk.label}`
      );
      if (!page.events || page.events.length === 0) break;
      events.push(...page.events);
      scrollId = page.scroll_id;
      onBatch(page.events.length);
    } catch {
      break;
    }
  }

  return events;
}

// ═══════════════════════════════════════════════════════════════════
// PUBLIC API
// ═══════════════════════════════════════════════════════════════════

/**
 * Collects access logs by splitting the time range into 6-hour chunks
 * and fetching up to MAX_CONCURRENCY streams in parallel.
 * 7 days = 28 chunks = up to 10 concurrent scroll streams.
 */
export async function collectAccessLogs(
  namespace: string,
  lbName: string,
  startTime: string,
  endTime: string,
  onProgress: (p: CollectionProgress) => void
): Promise<AccessLogEntry[]> {
  const query = `{vh_name="ves-io-http-loadbalancer-${lbName}"}`;
  const chunks = splitIntoChunks(startTime, endTime, CHUNK_HOURS);

  let collected = 0;
  let grandTotal = 0;
  let completedChunks = 0;

  onProgress({
    phase: 'fetching_logs',
    message: `Fetching access logs — ${chunks.length} streams (${CHUNK_HOURS}h windows, ${MAX_CONCURRENCY} concurrent, ${PAGE_SIZE}/page)...`,
    progress: 3,
    accessLogsCount: 0,
    securityEventsCount: 0,
    scrollPage: 0,
  });

  const updateProgress = () => {
    const pct = grandTotal > 0 ? Math.round((collected / grandTotal) * 100) : 0;
    // Progress bar: 3-43% range, based on collected/total when total is known
    const barProgress = grandTotal > 0
      ? Math.min(3 + Math.round((collected / grandTotal) * 40), 43)
      : 3; // Stay at 3% until we know the total
    onProgress({
      phase: 'fetching_logs',
      message: `Access logs — ${collected.toLocaleString()}${grandTotal > 0 ? ` / ${grandTotal.toLocaleString()}` : ''} fetched (${pct}%)`,
      progress: barProgress,
      accessLogsCount: collected,
      securityEventsCount: 0,
      scrollPage: completedChunks,
      estimatedTotal: grandTotal,
    });
  };

  const tasks = chunks.map((chunk) => () =>
    fetchChunkAccessLogs(
      namespace, query, chunk,
      (batchSize) => {
        collected += batchSize;
        updateProgress();
      },
      (totalHits) => {
        // Report total as soon as the chunk's initial response arrives
        grandTotal += totalHits;
        updateProgress();
      }
    ).then((logs) => {
      completedChunks++;
      updateProgress();
      return logs;
    })
  );

  const chunkResults = await parallelLimit(tasks, MAX_CONCURRENCY);
  const rawLogs = chunkResults.flat();

  // Normalize: detect and unwrap if API returns nested structures
  const allLogs = normalizeLogEntries<AccessLogEntry>(rawLogs, 'access-logs');

  console.log(`[LogCollector] Access logs done: fetched=${allLogs.length}, API total_hits sum=${grandTotal}`);

  onProgress({
    phase: 'fetching_logs',
    message: `Access logs complete: ${allLogs.length.toLocaleString()} records fetched (${chunks.length} streams)`,
    progress: 45,
    accessLogsCount: allLogs.length,
    securityEventsCount: 0,
    scrollPage: chunks.length,
    estimatedTotal: allLogs.length, // Use actual count at completion
  });

  return allLogs;
}

/**
 * Collects security events with the same parallel chunked approach.
 */
export async function collectSecurityEvents(
  namespace: string,
  lbName: string,
  startTime: string,
  endTime: string,
  onProgress: (p: CollectionProgress) => void,
  accessLogsCount: number
): Promise<SecurityEventEntry[]> {
  // Filter server-side by vh_name — same convention as access logs
  const query = `{vh_name="ves-io-http-loadbalancer-${lbName}"}`;

  console.log(`[LogCollector] Security events query: ${query}`);

  const chunks = splitIntoChunks(startTime, endTime, CHUNK_HOURS);

  let collected = 0;
  let grandTotal = 0;
  let completedChunks = 0;

  onProgress({
    phase: 'fetching_security',
    message: `Fetching security events — ${chunks.length} parallel streams...`,
    progress: 48,
    accessLogsCount,
    securityEventsCount: 0,
    scrollPage: 0,
  });

  const updateProgress = () => {
    const pct = grandTotal > 0 ? Math.round((collected / grandTotal) * 100) : 0;
    const barProgress = grandTotal > 0
      ? Math.min(48 + Math.round((collected / grandTotal) * 20), 68)
      : 48;
    onProgress({
      phase: 'fetching_security',
      message: `Security events — ${collected.toLocaleString()}${grandTotal > 0 ? ` / ${grandTotal.toLocaleString()}` : ''} fetched (${pct}%)`,
      progress: barProgress,
      accessLogsCount,
      securityEventsCount: collected,
      scrollPage: completedChunks,
      estimatedTotal: grandTotal,
    });
  };

  const tasks = chunks.map((chunk) => () =>
    fetchChunkSecurityEvents(
      namespace, query, chunk,
      (batchSize) => {
        collected += batchSize;
        updateProgress();
      },
      (totalHits) => {
        grandTotal += totalHits;
        updateProgress();
      }
    ).then((events) => {
      completedChunks++;
      updateProgress();
      return events;
    })
  );

  const chunkResults = await parallelLimit(tasks, MAX_CONCURRENCY);
  const allEvents = normalizeLogEntries<SecurityEventEntry>(chunkResults.flat(), 'security-events');

  console.log(`[LogCollector] Security events done: fetched=${allEvents.length}, API total_hits sum=${grandTotal}`);

  onProgress({
    phase: 'fetching_security',
    message: `Security events complete: ${allEvents.length.toLocaleString()} for this LB`,
    progress: 68,
    accessLogsCount,
    securityEventsCount: allEvents.length,
    scrollPage: chunks.length,
    estimatedTotal: allEvents.length,
  });

  return allEvents;
}
